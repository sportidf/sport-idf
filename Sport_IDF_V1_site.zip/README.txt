Sport IDF V1 — test gratuit sur téléphone.
1. Décompressez le ZIP.
2. Ouvrez index.html dans un navigateur pour tester.
3. Pour un vrai site public, il faudra héberger cette page et remplacer le stockage local par une base de données.
4. Instagram : ajoutez ensuite l'URL publique du site dans Profil > Modifier le profil > Liens.
